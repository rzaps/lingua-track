"""
Роутер для обработки прогресса (пока не используется)
"""

from aiogram import Router

router = Router()

# Логика прогресса уже реализована в commands.py 