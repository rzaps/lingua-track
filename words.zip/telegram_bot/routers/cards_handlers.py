"""
Роутер для обработки карточек (пока не используется)
"""

from aiogram import Router

router = Router()

# Логика карточек уже реализована в commands.py 